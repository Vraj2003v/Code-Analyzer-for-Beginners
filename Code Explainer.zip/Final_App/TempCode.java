import java.util.Scanner;

public class TempCode {
    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter something: ");

        
        String userInput = scanner.nextLine();

        System.out.println("You entered: " + userInput);

       
        scanner.close();
    }
}
